# Drug Blaster

A standalone retro arcade-style drug study game.

## Run locally
Open `index.html` in a modern browser.

## Publish with GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Select **Deploy from a branch**.
5. Choose the `main` branch and `/root`.
6. Save and wait for the GitHub Pages URL.

## Expanding the test bank
Edit the `const drugs = [...]` section in `index.html`. Each drug can automatically create:
- Brand → Generic
- Generic → Brand
- Drug → Class
- Drug → Indication

The included file contains 20 sample drugs (80 core prompts). Replace or expand them using the exact Top 200 list required by your school or program.
